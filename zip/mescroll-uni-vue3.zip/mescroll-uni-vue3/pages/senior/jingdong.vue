<template>
	<view>
		<!-- 模拟的标题 -->
		<image class="header" src="https://www.mescroll.com/img/jingdong/header.jpg" mode="aspectFit"/>
		
		<mescroll-body-diy @init="mescrollInit" top="100" bottom="100" @down="downCallback" @up="upCallback">
			<!-- 模拟的内容 -->
			<image src="https://www.mescroll.com/img/jingdong/jingdong1.jpg" mode="widthFix"/>
			<image src="https://www.mescroll.com/img/jingdong/jingdong2.jpg" mode="widthFix"/>
			<image src="https://www.mescroll.com/img/jingdong/jingdong3.jpg" mode="widthFix"/>
			<!-- 分页的数据列表 -->
			<good-list :list="goods"></good-list>
		</mescroll-body-diy>
		
		<!-- 模拟的底部 -->
		<image class="footer" src="https://www.mescroll.com/img/jingdong/footer.jpg" mode="aspectFit"/>
	</view>
</template>

<script setup>
	import { ref } from 'vue';
	import { onPageScroll, onReachBottom } from '@dcloudio/uni-app';
	import useMescroll from "@/uni_modules/mescroll-uni/hooks/useMescroll.js";
	import MescrollBodyDiy from "@/uni_modules/mescroll-uni/components/mescroll-diy/jingdong/mescroll-body.vue";
	import {apiGoods} from "@/api/mock.js"
	
	const goods = ref([]) // 数据列表
	const { mescrollInit, downCallback } = useMescroll(onPageScroll, onReachBottom) // 调用mescroll的hook
	
	// 上拉加载的回调: 其中num:当前页 从1开始, size:每页数据条数,默认10
	const upCallback = (mescroll)=>{
		apiGoods(mescroll.num, mescroll.size).then(res=>{
			const curPageData = res.list || [] // 当前页数据
			if(mescroll.num == 1) goods.value = []; // 第一页需手动制空列表
			goods.value = goods.value.concat(curPageData); //追加新数据
			mescroll.endSuccess(curPageData.length); // 请求成功, 结束加载
		}).catch(()=>{
			mescroll.endErr(); // 请求失败, 结束加载
		})
	}
</script>

<style>
	image{width: 100%;vertical-align: bottom;height:auto}
	.header{z-index: 9900;position: fixed;top: --window-top;left: 0;height: 100upx;background: white;}
	.footer{z-index: 9900;position: fixed;bottom: 0;left: 0;height: 100upx;background: white;}
</style>
