<template>
	<view>
		<!-- 模拟的标题 -->
		<image class="header" src="https://www.mescroll.com/img/taobao/header.jpg" mode="aspectFit"/>
		
		 <mescroll-body-diy @init="mescrollInit" top="100" bottom="100" @down="downCallback" @up="upCallback">
			<!-- 模拟的内容 -->
			<view class="imgs">
				<image src="https://www.mescroll.com/img/taobao/taobao1.jpg" mode="widthFix"/>
				<image src="https://www.mescroll.com/img/taobao/taobao2.jpg" mode="widthFix"/>
				<image src="https://www.mescroll.com/img/taobao/taobao3.jpg" mode="widthFix" style="border-top: 16rpx solid #eee"/>
			</view>
			<!-- 分页的数据列表 -->
			<good-list :list="goods"></good-list>
		</mescroll-body-diy>
		
		<!-- 模拟的底部 -->
		<image class="footer" src="https://www.mescroll.com/img/taobao/footer.jpg" mode="aspectFit"/>
	</view>
</template>

<script setup>
	import { ref } from 'vue';
	import { onPageScroll, onReachBottom } from '@dcloudio/uni-app';
	import useMescroll from "@/uni_modules/mescroll-uni/hooks/useMescroll.js";
	import MescrollBodyDiy from "@/uni_modules/mescroll-uni/components/mescroll-diy/taobao/mescroll-body.vue";
	import {apiGoods} from "@/api/mock.js"
	
	const goods = ref([]) // 数据列表
	const { mescrollInit, downCallback } = useMescroll(onPageScroll, onReachBottom) // 调用mescroll的hook
	
	// 上拉加载的回调: 其中num:当前页 从1开始, size:每页数据条数,默认10
	const upCallback = (mescroll)=>{
		apiGoods(mescroll.num, mescroll.size).then(res=>{
			const curPageData = res.list || [] // 当前页数据
			if(mescroll.num == 1) goods.value = []; // 第一页需手动制空列表
			goods.value = goods.value.concat(curPageData); //追加新数据
			mescroll.endSuccess(curPageData.length); // 请求成功, 结束加载
		}).catch(()=>{
			mescroll.endErr(); // 请求失败, 结束加载
		})
	}
</script>

<style>
	/*当下拉区域背景不是白色的时候,因iOS列表回弹,会在快速下拉刷新时,短时间显示body背景,导致下拉区域底部闪白线的问题,可通过给body设置下拉区域的背景解决*/
	page{
		background-image: url(https://www.mescroll.com/img/taobao/mescroll-bg-down-fix.png);
		background-size: 100% 150px;
		background-repeat: no-repeat;
	}
	
	
	image{width: 100%;vertical-align: bottom;height:auto}
	.imgs{background-color: #fff;}
	.imgs image{min-height: 100rpx;}
	.header{z-index: 9900;position: fixed;top: --window-top;left: 0;height: 100upx;background: linear-gradient(90deg,#FD8F00,#FF4F00);}
	.footer{z-index: 9900;position: fixed;bottom: 0;left: 0;height: 100upx;background: linear-gradient(90deg,#F9D6EA,white);}
</style>
