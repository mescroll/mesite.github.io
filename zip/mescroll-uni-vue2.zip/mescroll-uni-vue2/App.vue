<script>
	export default {
		onLaunch: function () {
			console.log('App Launch')
		},
		onShow: function () {
			console.log('App Show')
		},
		onHide: function () {
			console.log('App Hide')
		}
	}
</script>

<style>
	page{background-color: #fff}
	
	view,
	text,
	image,
	input,
	textarea {
		box-sizing: border-box;
	}
	
	image{will-change: transform;}
</style>
