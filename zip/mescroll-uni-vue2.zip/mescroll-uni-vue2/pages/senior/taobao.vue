<template>
	<view>
		<!-- 模拟的标题 -->
		<image class="header" src="https://www.mescroll.com/img/taobao/header.jpg" mode="aspectFit"/>
		
		 <mescroll-body-diy @init="mescrollInit" top="100" bottom="100" @down="downCallback" @up="upCallback">
			<!-- 模拟的内容 -->
			<view class="imgs">
				<image src="https://www.mescroll.com/img/taobao/taobao1.jpg" mode="widthFix"/>
				<image src="https://www.mescroll.com/img/taobao/taobao2.jpg" mode="widthFix"/>
				<image src="https://www.mescroll.com/img/taobao/taobao3.jpg" mode="widthFix" style="border-top: 16rpx solid #eee"/>
			</view>
			<!-- 分页的数据列表 -->
			<good-list :list="goods"></good-list>
		</mescroll-body-diy>
		
		<!-- 模拟的底部 -->
		<image class="footer" src="https://www.mescroll.com/img/taobao/footer.jpg" mode="aspectFit"/>
	</view>
</template>

<script>
	import MescrollBodyDiy from "@/uni_modules/mescroll-uni/components/mescroll-diy/taobao/mescroll-body.vue";
	import MescrollMixin from "@/uni_modules/mescroll-uni/components/mescroll-uni/mescroll-mixins.js";
	import {apiGoods} from "@/api/mock.js"
	
	export default {
		mixins: [MescrollMixin], // 使用mixin
		components: {
			MescrollBodyDiy // 避免与main.js注册的全局组件名称相同,否则注册组件失效(iOS真机 APP HBuilderX2.7.9)
		},
		data() {
			return {
				goods: [] // 数据列表
			}
		},
		methods: {
			// 下拉刷新的回调
			downCallback(){
				// 这里可以继续调用其他数据接口
				// ...
				// 重置列表为第一页 (自动执行 page.num=1, 再触发upCallback方法 )
				this.mescroll.resetUpScroll() 
			},
			/*上拉加载的回调: 其中page.num:当前页 从1开始, page.size:每页数据条数,默认10 */
			upCallback(page) {
				//联网加载数据
				apiGoods(page.num, page.size).then(res=>{
					//联网成功的回调,隐藏下拉刷新和上拉加载的状态;
					this.mescroll.endSuccess(res.list.length);

					//设置列表数据
					if(page.num == 1) this.goods = []; //如果是第一页需手动制空列表
					this.goods=this.goods.concat(res.list); //追加新数据
				}).catch(()=>{
					//联网失败, 结束加载
					this.mescroll.endErr();
				})
			}
		}
	}
</script>

<style>
	/*当下拉区域背景不是白色的时候,因iOS列表回弹,会在快速下拉刷新时,短时间显示body背景,导致下拉区域底部闪白线的问题,可通过给body设置下拉区域的背景解决*/
	page{
		background-image: url(https://www.mescroll.com/img/taobao/mescroll-bg-down-fix.png);
		background-size: 100% 150px;
		background-repeat: no-repeat;
	}
	
	
	image{width: 100%;vertical-align: bottom;height:auto}
	.imgs{background-color: #fff;}
	.imgs image{min-height: 100rpx;}
	.header{z-index: 9900;position: fixed;top: --window-top;left: 0;height: 100upx;background: linear-gradient(90deg,#FD8F00,#FF4F00);}
	.footer{z-index: 9900;position: fixed;bottom: 0;left: 0;height: 100upx;background: linear-gradient(90deg,#F9D6EA,white);}
</style>
